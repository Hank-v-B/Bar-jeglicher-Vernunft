# Kapitel 2.4 – Hank {#kap-2-4-hank}

<!--NAV:START-->
<nav aria-label="Kapitel Navigation" class="mc-nav" role="navigation">
<div class="mc-nav-inner">
<a class="nav-link home" href="./index.html">Zur Startseite</a>
<div class="mc-nav-spacer"></div>
<a class="nav-link prev" href="./Kap_2_3_Mockridge.html">← Zurück</a>
<a class="nav-link next" href="./Kap_2_5_Mockridge.html">Weiter →</a>
</div>
</nav>
<!--NAV:END-->
Freitag hat ein Geräusch. Es ist dieses Ausatmen, wenn Leute glauben, sie hätten die Woche überlebt.

Ich stehe hinter dem Tresen und sehe ihn, noch bevor er ganz drin ist: Mockridge.
Die arme Sau hat im Büro geschuftet. Das sitzt in den Schultern, nicht in Wunden.

Er müsste jetzt abschalten können. Aber ich weiß: er kann es nicht.

Und dann passiert etwas Unpassendes: er strahlt, als hätte jemand in ihm einen Schalter umgelegt.
Nicht höflich, nicht tapfer – echt. Als wäre heute „Heute nicht“.

Da wird mir klar: Heute Abend ist der Name der Bar Programm.
Hier läuft nichts mehr vernünftig. Und genau das ist die Erlösung.

Ich stelle ein Glas hin. „Dann machen wir’s richtig falsch“, sage ich.




