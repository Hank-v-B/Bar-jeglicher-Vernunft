# Kapitel 2.6 – Francine {#kap-2-6-francine}

<!--NAV:START-->
<nav aria-label="Kapitel Navigation" class="mc-nav" role="navigation">
<div class="mc-nav-inner">
<a class="nav-link home" href="./index.html">Zur Startseite</a>
<div class="mc-nav-spacer"></div>
<a class="nav-link prev" href="./Kap_2_5_Mockridge.html">← Zurück</a>
<a class="nav-link next" href="./Kap_2_7_Hank.html">Weiter →</a>
</div>
</nav>
<!--NAV:END-->
Der Abend hat eine eigene Physik. Erst leicht, dann kippt er nach vorn.
Die Drinks werden härter, die Sätze kürzer, die Lacher lauter.

Mockridge ist schon so voll, dass er alle Stationen durchläuft:
feuchtfröhlich, sentimental, dann dieser unausweichliche Jammer.

„Die Welt ist kaputt“, sagt er, und ich sehe, wie bequem Schuld sein kann, wenn sie bei anderen liegt.
Alles ist „die da draußen“. Nur er nicht.

Hank wird stiller, je lauter es wird. Ich bleibe wach, weil jemand wach bleiben muss.
Bar jeglicher Vernunft: heute ist der Name keine Pointe, sondern Zustand.




