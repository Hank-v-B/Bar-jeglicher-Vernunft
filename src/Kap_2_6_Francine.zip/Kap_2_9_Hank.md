# Kapitel 2.9 – Hank {#kap-2-9-hank}

<!--NAV:START-->
<nav aria-label="Kapitel Navigation" class="mc-nav" role="navigation">
<div class="mc-nav-inner">
<a class="nav-link home" href="./index.html">Zur Startseite</a>
<div class="mc-nav-spacer"></div>
<a class="nav-link prev" href="./Kap_2_8_Aurelia.html">← Zurück</a>
<a class="nav-link next" href="./Kap_2_10_Francine.html">Weiter →</a>
</div>
</nav>
<!--NAV:END-->
Der Abend rollt jetzt. Nicht „läuft“ – rollt, wie ein Fass bergab.

„Viva la Revolution“ ist zum Refrain geworden. Und ich merke: jedes Mal heißt das eine Runde.
Kurzes Innehalten, dann Jubel, dann Augen zu mir.

Ich stelle Gläser hin wie Munition, aber ohne Krieg. Nur Vergessen.

Und in mir denkt es, trocken und ehrlich: geil.
Heute ist erst Freitag.

Bar jeglicher Vernunft: wenn der Chor ruft, läuft das Geschäft.
Ich hebe ein Glas. „Auf die Revolution“, sage ich.
Und der Laden antwortet: „VIVA LA REVOLUTION!“




