# Kapitel 1 {#kap-1}

<!--NAV:START-->
<nav aria-label="Kapitel Navigation" class="mc-nav" role="navigation">
<div class="mc-nav-inner">
<a class="nav-link home" href="./index.html">Zur Startseite</a>
<div class="mc-nav-spacer"></div>
<a class="nav-link next" href="./Kap_1_1_Colbert.html">Weiter →</a>
</div>
</nav>
<!--NAV:END-->
Ein Satz reicht, und der Raum kippt.

Nicht nach außen. Nach innen.

Eben noch: Gläser, Holz, Lachen – diese milde Übereinkunft, die man „Abend“ nennt.  
Dann fällt eine Frage, klein wie Metall auf Tisch.

Und sofort beginnt etwas zu zählen, das niemand laut ausspricht.  
Nicht Beträge.  
Abstände.

Ich sehe es an den winzigen Signalen: ein Atem, der stolpert; Augen, die ausweichen; eine Hand, die das Glas fester umfasst, als müsste sie sich halten. Und ich merke, wie ich selbst einen Moment zu lange still bleibe – als könnte ich den Satz zurückholen, wenn ich nur früh genug bremse.

Mein Reflex ist alt: glätten, vermitteln, den Moment zurück in die Normalform drücken.

Aber ich habe gelernt, dass Glätten oft nur Tarnung ist.  
Und Tarnung kostet – später.

Also bleibe ich still.  
Nicht aus Schwäche.  
Weil ich sehen will, was gerade aufsteht.

Dann fällt das Wort „teilen“.  
Ein Pflasterwort.  
Harmlos im Klang.

Doch ich spüre, wie es in zwei Richtungen zieht:  
Für manche ist es Fairness.  
Für andere ist es ein Stempel.

Ich kenne diesen Moment. Nicht, weil er sich wiederholt – sondern weil die Mechanik dieselbe ist: Gesichter bleiben freundlich, aber der Blick wird zur Messung. Niemand ist der Lauteste. Und doch kippt ein Raum manchmal in Sekundenschnelle.

Und ich weiß: Das hier ist keine Informationsfrage.  
Das ist eine Prüfung.

Prüfungen bestehen Menschen nicht mit Nettigkeit.  
Sondern mit Klarheit.




