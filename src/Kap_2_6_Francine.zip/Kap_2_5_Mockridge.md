# Kapitel 2.5 – Mockridge {#kap-2-5-mockridge}

<!--NAV:START-->
<nav aria-label="Kapitel Navigation" class="mc-nav" role="navigation">
<div class="mc-nav-inner">
<a class="nav-link home" href="./index.html">Zur Startseite</a>
<div class="mc-nav-spacer"></div>
<a class="nav-link prev" href="./Kap_2_4_Hank.html">← Zurück</a>
<a class="nav-link next" href="./Kap_2_6_Francine.html">Weiter →</a>
</div>
</nav>
<!--NAV:END-->
Ich sehe sie sofort: die Gruppe schwitzt. Nicht vom Tanzen, vom Festhalten.
Diese Büro-Disziplin, die selbst im Feierabend noch die Zähne zusammenpresst.

Heute lasse ich das nicht zu.

Ich stelle mich hin wie eine Unterbrechung und sage: „Stopp. Das da bleibt heute draußen.“
Ein paar schauen mich an, als würde ich gleich ein Meeting eröffnen.

„Aufstehen“, sage ich. „Wir sprengen euch. Wir sprengen diese Formation.“

Ich zeige rüber zur Ecke, die nicht Tanzfläche heißt, aber es ist: der Mambotron.
„Jetzt erobern wir den Mambotron.“

Sie rollen mit den Augen, aber sie stehen. Einer nach dem anderen.
Und plötzlich fühlt sich der Lärm nicht mehr wie Stress an, sondern wie Motor.

Ich setze den ersten Schritt auf den Mambotron und entscheide: Ich gehe nicht runter, bevor diese Woche aus uns raus ist.




