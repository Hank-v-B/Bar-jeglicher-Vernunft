# Kapitel 2.7 – Hank {#kap-2-7-hank}

<!--NAV:START-->
<nav aria-label="Kapitel Navigation" class="mc-nav" role="navigation">
<div class="mc-nav-inner">
<a class="nav-link home" href="./index.html">Zur Startseite</a>
<div class="mc-nav-spacer"></div>
<a class="nav-link prev" href="./Kap_2_6_Francine.html">← Zurück</a>
<a class="nav-link next" href="./Kap_2_8_Aurelia.html">Weiter →</a>
</div>
</nav>
<!--NAV:END-->
Als Mockridge richtig voll ist, geht die Tür auf.
Rein kommt ein abgerissener, aber athletischer Mitdreißiger. Augen zu klar.

Er setzt sich an die Theke. Drei, vier Drinks, langsam, als müsste er erst anlaufen.
Dann schaut er rüber, hört Mockridge zu – und springt auf.

Er brüllt: wir müssen aufstehen, die Großen bekämpfen, die Reichen stürzen, Geld verteilen.
Nicht sauber, nicht logisch – aber Energie.

Mockridge bleibt wie angewurzelt, staunt, und als der Fremde endet, schreit er:
„DER MANN HAT RECHT! AUF GEHT'S, HOLEN WIR SIE UNS!“

Ich stelle ein Glas ab und rechne kurz: Begeisterung, Aggression, Umkippen.
Bar jeglicher Vernunft: heute ist der Name Warnschild.




