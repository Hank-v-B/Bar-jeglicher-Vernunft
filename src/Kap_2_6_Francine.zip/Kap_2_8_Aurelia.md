# Kapitel 2.8 – Aurelia {#kap-2-8-aurelia}

<!--NAV:START-->
<nav aria-label="Kapitel Navigation" class="mc-nav" role="navigation">
<div class="mc-nav-inner">
<a class="nav-link home" href="./index.html">Zur Startseite</a>
<div class="mc-nav-spacer"></div>
<a class="nav-link prev" href="./Kap_2_7_Hank.html">← Zurück</a>
<a class="nav-link next" href="./Kap_2_9_Hank.html">Weiter →</a>
</div>
</nav>
<!--NAV:END-->
Erst bin ich entsetzt. Dann merke ich: es ist so pathetisch, dass es fast komisch ist.
Revolution in einer Bar mit klebrigen Gläsern und Montag im Nacken.

Ich stelle mein Glas ab, steige auf den Tisch und reiße die Arme hoch.
„VIVA LA REVOLUTION!“

Ein kurzes Durchatmen im Publikum, dann bricht es los.
Hände in die Luft, Geschrei, ein Chor, der alles entschärft, indem er es größer macht als ernst.

Alle brüllen mit: „VIVA LA REVOLUTION!“

Der Fremde wirkt kurz irritiert, dann grinst er.
Mockridge leuchtet, als hätte er eine Fahne gefunden.
Und ich denke: Wenn schon Wahnsinn, dann bitte gemeinsam. Ohne Fäuste. Nur mit Stimmen.




