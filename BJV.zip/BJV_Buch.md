# Bar jeglicher Vernunft

## Kapitel 1
- [[Kap_1_Thomas|Kapitel 1 – Thomas]]
  - [[Kap_1_1_Colbert|Kapitel 1.1 – Colbert]]
  - [[Kap_1_2_Aurelia|Kapitel 1.2 – Aurelia]]

## Kapitel 2
- [[Kap_2_Aurelia|Kapitel 2 – Aurelia]]
  - [[Kap_2_1_Colbert|Kapitel 2.1 – Colbert]]
  - [[Kap_2_2_Francine|Kapitel 2.2 – Francine]]
