# Kapitel 1.1 – Colbert

Der Satz hatte den Ton von Ordnung.

Ich habe ihn gesagt, weil irgendwer ihn sagen musste.

Man kann Menschen beim Zerfall zuschauen, wenn man poetisch genug ist. Wenn man sich damit beruhigt, dass alles eben „Prozess“ sei. Ich bin nicht poetisch. Ich bin nur allergisch gegen sinnlose Verluste.

Eine Woche ist lang genug, um aus einer Kränkung eine Geschichte zu bauen. Man poliert sie, man übt sie, man bringt sie auf Form. Und wenn man zurückkommt, ist niemand mehr beim Ereignis – alle sind schon beim Urteil.

Als ich wieder da war, war das Erste nicht ein Wort.

Es war die Ordnung der Abstände.

Nicht wer wo sitzt, sondern wer wem ausweicht. Wer den Blick hält. Wer ihn verliert. Wer zu früh da ist, weil er Kontrolle braucht. Wer zu spät kommt, weil er testen will, ob ihn noch jemand will.

Ich setzte mich nicht sofort. Nicht aus Vorsicht. Aus Messung.

Der Stolze war da. Kinn minimal zu hoch. Der Moralische auch, mit diesem Gesichtsausdruck, als wäre die Welt ein Gerichtssaal und er die Anklage. Die Elegante hielt sich über Wasser, indem sie Distanz hielt. Und da war der Leise, der beim letzten Mal diese Runde vorgeschlagen hatte – zu ruhig, zu aufmerksam. Menschen, die so gucken, sind gefährlich. Nicht, weil sie böse sind. Weil sie sehen.

Dann sah ich den anderen.

Das kleine, saubere Grinsen. Dieses „mach mal“, das eigentlich heißt: _Ich werde dir zeigen, dass du keine Autorität hast._

Ich ignorierte es.

Ignorieren ist auch Macht. Man muss sie nur aushalten.

„Setzt euch,“ sagte ich.

Nicht laut. Nicht freundlich. So, dass es passiert.

Zwei gehorchten sofort, weil sie es gewohnt sind, dass Entscheidungen irgendwo fallen.

Zwei zögerten, weil sie noch prüfen wollten, ob ich diesmal wirklich durchziehe.

Einer schnaubte, als hätte ich ihm gerade sein Spielzeug weggenommen.

Gut.

„Wir reden richtig,“ sagte ich. „Nicht über Deutungen. Nicht darüber, wer sich wie gefühlt hat. Wir reden über Fakten, Regeln, Konsequenzen.“

Ich hörte sofort den Widerstand. Nicht gegen den Inhalt.

Gegen die Zumutung, dass es jetzt eine Form geben soll.

„Fakten,“ sagte jemand und lachte trocken.

„Ja,“ sagte ich. „Fakten. Und wenn’s keine gibt, dann sagen wir wenigstens ehrlich, dass wir nur noch erzählen.“

Niemand mag das Wort _ehrlich_, wenn es die eigenen Ausreden frisst.

Ich setzte mich. Nicht an den Rand. Nicht ins Zentrum. So, dass der Tisch zusammenhält.

„Erster Punkt,“ sagte ich. „Letztes Mal ist es gekippt bei der Rechnung. Nicht wegen Geld. Wegen Respekt. Heute klären wir: Was war das? Wer hat wen markiert? Und was machen wir beim nächsten Mal anders?“

„Markiert,“ sagte der Moralische, als wäre das Wort ein Angriff.

„Ist es,“ sagte ich. „Und du weißt es.“

Ich ließ den Blick einmal rumgehen.

„Jeder spricht, wenn er dran ist. Heute sagt jeder drei Dinge: Was er will. Was er befürchtet. Und was er bereit ist zu geben. Dann haben wir was, womit man arbeiten kann.“

Ich spürte, wie die Gruppe sich dagegen sträubt.

Weil Geben weh tut.

Weil es Status kostet.

Gut.

Wenn es nicht weh tut, ist es keine Einigung.

Der Leise sah mich an, als würde er messen, ob ich’s ernst meine.

Ich hielt den Blick.

„Und bevor einer wieder so tut, als wäre das hier zufällig,“ sagte ich, „sage ich’s klar: Wenn wir heute keinen Ablauf finden, dann war das die letzte Runde. Dann geht jeder wieder sein eigenes Ding machen. Aber dann soll keiner später erzählen, es habe ihn überrascht.“

Die Stille danach war nicht peinlich.

Sie war funktional.

So klingt es, wenn eine Gruppe zum ersten Mal versteht, dass sie nicht nur redet.

Dass sie verhandelt.

Und dass jede Verhandlung einen Preis hat.
