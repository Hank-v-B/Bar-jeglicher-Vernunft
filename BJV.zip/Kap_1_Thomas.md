# Kapitel 1 – Thomas

Ein Satz reicht, und der Raum kippt.

Nicht nach außen. Nach innen.

Eben noch: Gläser, Holz, Lachen – diese milde Übereinkunft, die man „Abend“ nennt.  
Dann fällt eine Frage, klein wie Metall auf Tisch.

Und sofort beginnt etwas zu zählen, das niemand laut ausspricht.  
Nicht Beträge.  
Abstände.

Ich sehe es an den winzigen Signalen: ein Atem, der stolpert; Augen, die ausweichen; eine Hand, die das Glas fester umfasst, als müsste sie sich halten. Und ich sehe Thomas – wie er einen Moment zu lange still bleibt, als würde er prüfen, ob er den Satz zurückholen kann.

Mein Reflex ist alt: glätten, vermitteln, den Moment zurück in die Normalform drücken.

Aber ich habe gelernt, dass Glätten oft nur Tarnung ist.  
Und Tarnung kostet – später.

Also bleibe ich still.  
Nicht aus Schwäche.  
Weil ich sehen will, was gerade aufsteht.

Dann fällt das Wort „teilen“.  
Ein Pflasterwort.  
Harmlos im Klang.

Doch ich spüre, wie es in zwei Richtungen zieht:  
Für manche ist es Fairness.  
Für andere ist es ein Stempel.

Thomas wirkt, als hätte er diesen Moment schon einmal erlebt – nur in einem anderen Raum, mit anderen Gesichtern. Seine Augen gehen kurz herum, nicht suchend, eher messend. Er ist nicht der Lauteste, aber er merkt, wenn eine Gruppe kippt.

Und ich weiß: Das hier ist keine Informationsfrage.  
Das ist eine Prüfung.

Prüfungen bestehen Menschen nicht mit Nettigkeit.  
Sondern mit Klarheit.
