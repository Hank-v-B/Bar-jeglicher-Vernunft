Ein Satz reicht, und der Raum kippt.

Nicht nach außen. Nach innen.

Eben noch: Gläser, Holz, Lachen – diese milde Übereinkunft, die man „Abend“ nennt.\
Dann fällt eine Frage, klein wie Metall auf Tisch.

Und sofort beginnt etwas zu zählen, das niemand laut ausspricht.\
Nicht Beträge.\
Abstände.

Ich erkenne es an den winzigen Signalen: Atem, der stolpert; Augen, die ausweichen; eine Hand, die das Glas fester umfasst, als müsse sie sich halten.

Mein Reflex ist alt: glätten, vermitteln, den Moment zurück in die Normalform drücken.

Aber ich habe gelernt, dass Glätten oft nur Tarnung ist.\
Und Tarnung kostet – später.

Also bleibe ich still.\
Nicht aus Schwäche.\
Weil ich sehen will, was gerade aufsteht.

Dann fällt das Wort „teilen“.\
Ein Pflasterwort.\
Harmlos im Klang.

Doch ich spüre, wie es in zwei Richtungen zieht:\
Für manche ist es Fairness.\
Für andere ist es ein Stempel.

Und ich weiß: Das hier ist keine Informationsfrage.\
Das ist eine Prüfung.

Prüfungen bestehen Menschen nicht mit Nettigkeit.\
Sondern mit Klarheit.
